package com.labbook.lab4.service;


import com.labbook.lab4.dto.EmployeeEx;

public interface EmployeeServiceInterface {
	EmployeeEx getEmpId(int id);
//	EmployeeEx viewEmpById(int empId);

}


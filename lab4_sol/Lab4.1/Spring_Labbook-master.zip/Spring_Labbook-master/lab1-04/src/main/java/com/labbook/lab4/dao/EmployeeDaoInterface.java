package com.labbook.lab4.dao;

import com.labbook.lab4.dto.EmployeeEx;

public interface EmployeeDaoInterface {
	EmployeeEx getEmpId(int id);
//	EmployeeEx viewEmpById(int empId);


}
package com.labbook.lab402;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab402ApplicationTests {

	@Test
	void contextLoads() {
	}

}
